# iiRDS Request API Project

## OpenAPI Specification

The OpenAPI specification is available at [spec/iirdsapi.yaml](spec/iirdsapi.yaml).

You can also view the specification in an HTML format at [spec/iirdsapidoc.html](spec/iirdsapidoc.html). To display this HTML page, deploy the files `iiRDS.jpg`, `iirdsapi.yaml`, and `iirdsapidoc.html` to a web server.

## API mockup

An API mockup is available in the `mock-api` directory. For more details, refer to [mock-api/README.md](mock-api/README.md).
