// validationHelpers.js
const { version: currentVersion } = require('../package.json');
const {validateIri} = require('validate-iri');
const SparqlParser = require('sparqljs').Parser;
const { validation } = require('../config/config.json');


function respondError(res, status, detail) {
    return res.status(status).type('application/problem+json').send({'status':status, 'detail':detail});
}

function validateIRI(res, next, iri) {
    if (!iri) {
        respondError(res,400,"The mandatory IRI parameter was not assigned in the request.");
    }

    // Validate the IRI using the validate-iri package
    if (validateIri(iri) === undefined) {
         // If valid, proceed
        next();
    } else {
        respondError(res,400,`Invalid IRI according to RFC3987: '${iri}'`);
    }
}

function validateSPARQL(query) {
    const parser = new SparqlParser();
    try {
        parser.parse(query); // This will throw an error if the query is invalid
        return true
    } catch (error) {
        console.log("Error parsing SPARQL: "+query+" ERROR:" + error)
        return false
    }
}

function validateMimeType(res, next, mimetype) {    
    const allowedMimeTypes = validation.mimeTypes;
    if(allowedMimeTypes.includes(mimetype)) {
        next()
    } else {
        respondError(res,400,`The provided mime type '${mimetype}' is not supported.`);
    };
}

function validatePath(res, next, path) {
    if (path.startsWith("..") || path.includes("\\") || path.includes(":")) {
        respondError(res,400,`The submitted path parameter value '${path}' is not valid.`);
    } else {
        next();
    }
}

function validateVersion(res, next, apiversion) {
    const allowedVersions = validation.versions
    if(apiversion) {
        if (/^v\d+\.\d+\.\d+$/.test(apiversion)) {
            if(!allowedVersions.includes(apiversion)) {
                respondError(res,400,`The submitted apiversion value \'${apiversion}\' does not match a version of this API. Choose from one of the following: ${allowedVersions.join(', ')}. The latest version is: v1.0.0`);
            } else {
                next()
            }
        } else {
            respondError(res,400,`The submitted apiversion value \'${apiversion}\' does not match the versioning format \'vmajor.minor.patch\'. The latest version is: v1.0.0`);
        }
    } else {
        respondError(res, 400,'The mandatory request parameter \'apiversion\' is missing.');
    }
}

// Export the functions
module.exports = {
validateVersion,
validateIRI,
validatePath,
validateMimeType,
validateSPARQL,
respondError
};