const express = require('express'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser');
    marked = require('marked');
    path = require('path');
    log = require('morgan'),
    cors = require('cors'),
    multer = require('multer'),
    swaggerUi = require("swagger-ui-express"),
    upload = multer(),
    app = express(),
    fs = require('fs'),
    YAML = require('yaml'),
    PORT = process.env.PORT || 8080,
    NODE_ENV = process.env.NODE_ENV || 'development';


// don't send specific response header fields
app.disable('etag');
app.disable('x-powered-by');

app.set('port', PORT);
app.set('env', NODE_ENV);

app.use(cors());
app.use(log('tiny'));

//setup spec
let yamlFile = "";
if (fs.existsSync('./spec/iirdsapi.yaml')) {
	yamlFile = fs.readFileSync('./spec/iirdsapi.yaml', 'utf8');
} else {
	yamlFile = fs.readFileSync('../spec/iirdsapi.yaml', 'utf8');
}
 
const swaggerDocument = YAML.parse(yamlFile)

app.use('/spec', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.get('/', function(req,res) {
    console.log("Sending home page" + __dirname+'/README.md');
    const content = fs.readFileSync(__dirname+'/README.md', 'utf8');
    res.send(
        "<html><head><title>iiRDS Request API Mockup</title><style>body {font-family: sans-serif;margin:3em}</style></head><body>"    
        + marked.marked(content)
        +"</body></html>"
    );
});


// parse multipart/form-data
app.use(upload.array()); 
app.use(express.static('public'));

app.use(cookieParser());


// parse application/json
app.use(express.json());

// parse raw text
app.use(express.text({ type: 'text/plain' }));

// parse application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

require('./routes')(app);

app.use(cookieParser());

// catch 404
app.use((req, res, next) => {
    // log.error(`Error 404 on ${req.url}.`);
    res.status(404).send({ status: 404, error: 'Not found' });
});

// catch errors
app.use((err, req, res, next) => {
    const status = err.status || 500;
    const msg = err.error || err.message;
    // log.error(`Error ${status} (${msg}) on ${req.method} ${req.url} with payload ${req.body}.`);
    res.status(status).send({ status, error: msg });
});


module.exports = app;

app.listen(PORT, () => {
    console.log(
        `Express Server started on Port ${app.get(
            'port'
        )} | Environment : ${app.get('env')}`
    );
});


