const express = require('express');
const api = require('../services/api');
const router = new express.Router();
const { validateVersion, validateIRI, validatePath, validateMimeType, validateSPARQL, respondError } = require('../validation/validationHelpers')


// check for valid {apiversion} parameter before heading on to process the request.
// In future there must also be a version specific forwarding of requests to according API version logic.
router.param('apiversion', (req, res, next, apiversion) => {
  validateVersion(res, next, apiversion)
});

// Middleware to validate the IRI parameter whenever it exists
router.param('iri', (req, res, next, iri) => {
  validateIRI(res, next, iri)
});

router.param('iiRDSContainerFilePath', (req, res, next, iiRDSPackageFilePath) => {
  validatePath(res, next, iiRDSPackageFilePath)
});

router.param('mimetype', (req, res, next, mimetype) => {
  validateMimeType(res, next, mimetype)
});

router.get('/:apiversion/features', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
  };


  try {
    const result = await api.retrieveSupportedApiFeatures(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.post('/:apiversion/resources/', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "maxCount": req.query.maxCount,
    "offset": req.query.offset,
    "query": req.query.query,
  };

  options.query = req.body;

  try {
    const result = await api.retrieveIirdsRdfResourcesViaQuery(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesAndObjectRessourcesForIirdsDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/children', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesForAllChildrenOfDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/next', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesForFollowingSiblingDirectoryNodeOfDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/parents', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesForAllParentsOfDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/previous', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesForPreviousSiblingDirectoryNodeOfDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/roots', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.getPropertiesOfAllRootLevelDirectoryNodesForGivenDirectoryNode(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/directorynodes/:iri/trees', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrieveDirectoryNodeTreesForDirectoryNodes(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/documents/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesOfIirdsDocument(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/fragments/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesOfIirdsFragment(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/packages/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };

  try {
    const result = await api.retrievePropertiesOfIirdsPackage(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/packages/:iri/files/:iiRDSContainerFilePath', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iiRDSContainerFilePath": req.params.iiRDSContainerFilePath,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrieveSpecificFileFromIirdsPackage(options);
    console.log(result)
    res.status(result.status || 200).sendFile(result.data, (err) => {
      if (err) {
        console.error('Error sending file:', err);
        respondError(res, 500, "Internal error");
      }
    });
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/topics/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesOfIirdsTopic(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/:iri/directorynodes', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrievePropertiesOfDirectoryNodeBelongingToInformationUnit(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/informationunits/:iri/renditions/:mimetype/content', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
    "mimetype": req.params.mimetype,

  };


  try {
    const result = await api.retrieveRenditionOfInformationUnitInSpecificFormat(options);
    res.status(result.status || 200).sendFile(result.data, result.options, (err) => {
      if (err) {
        console.error('Error sending file:', err);
        respondError(res, 500, "Internal error");
      }
    })
  }
  catch (err) {
      respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/package/:iri/content', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrieveIirdsContainerAsZip(options);
    res.set('Content-Type',"application/iirds+zip");
    res.set('Content-Disposition', 'attachment; filename="PI-Fan.iirds"');
    res.status(result.status || 200).sendFile(result.data, (err) => {
      if (err) {
        console.error('Error sending file:', err);
        respondError(res, 500, "Internal error");
      }
    });
  }
  catch (err) {
    console.error('Error:', err);
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/schema', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
  };

  try {
    const result = await api.retrieveIirdsSchema(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.get('/:apiversion/resources/:iri', async (req, res, next) => {
  let options = {
    "apiversion": req.params.apiversion,
    "iri": req.params.iri,
  };


  try {
    const result = await api.retrieveIirdsResourceByIri(options);
    res.status(result.status || 200).send(result.data);
  }
  catch (err) {
    respondError(res, 500, "Internal error");
  }
});

router.post('/:apiversion/sparql', async (req, res, next) => {

  let options = {
    "apiversion": req.params.apiversion,
    "queryResultFormat": req.query.queryResultFormat,
    "queryType": req.query.queryType,
    "query": req.body
  };

  const validSPARQL = validateSPARQL(options.query)

  if (validSPARQL) {
    try {
      const result = await api.retrieveSparqlQueryResults(options);
      res.status(result.status || 200).send(result.data);
    }
    catch (err) {
      respondError(res, 500, "Internal error");
    }
  } else {
    respondError(res, 400, `The SPARQL query '${options.query}' is invalid.`);
  }

});

module.exports = router;