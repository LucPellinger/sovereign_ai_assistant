# iiRDS Request API Mockup

## Overview

This API mockup allows developers to experiment with the iiRDS API, providing a simplified starting point for implementing the full specification.

The mockup includes all routes defined by the iiRDS Request API specification and generates sample responses to incoming requests. While these responses are syntactically correct per the iiRDS specification, they represent static data rather than a fully dynamic API implementation. Responses are based on [iiRDS sample content](https://www.iirds.org/materials/sample-content) and do not vary based on request parameters.

For example: The `/resources` route will return the same set of results regardless of the query parameters provided in the request body.

However, the API mockup does validate API call parameters for correct syntax and structure.

The API mockup is implemented as a Node.js project, making it easy to run in any environment with Node.js installed. The mockup code is generated from the OpenAPI 3 definition of the iiRDS request. It integrates the Node.js Express library and is designed to run independently as a standalone web server.

Additionally, a Dockerfile is provided to simplify running the mock API in a containerized environment.

## Getting started

### Getting started in a NodeJS environment

To run the mock API project:

1. Make sure the latest version of NodeJS is installed
2. Switch to the root folder of this project (`mock-api` folder).
3. Install the NodeJS package:

   ``npm install``
4. Run the API mockup server:

  ``npm run start``

The API mockup is now available on [http://localhost:8080/](http://localhost:8080/).

### Getting stated in in a containerized environment

To run the API mockup as container:

1. Make sure docker is installed.
2. Switch to the root folder of this project (`mock-api` folder).
3. Build the container:

   ``docker build -t iirds-mock-api .``

4. Run the container:

   ``docker run -p 8080:8080 iirds-mock-api``

The API mockup is now available at [http://localhost:8080/](http://localhost:8080/).

### Using SwaggerUI for Testing

The API mockup includes an integrated SwaggerUI, allowing you to test and interact with the API directly from the specifications displayed in the UI. SwaggerUI lets you edit request parameters, execute requests, and view results within the interface.

You can access SwaggerUI at:

[http://localhost:8080/spec](http://localhost:8080/spec)

To run a request from the SwaggerUI:

1. Navigate to the desired request on the page.
2. Press the **Try it out** button.
3. Enter parameters and, if required, the request body in the **Parameters** section.
4. Press the **Execute** button.
5. Check the **Response** section to view the results.

### Accessing the iiRDS Request API directly

The endpoints are accessible as defined in the API specification via:

``http://localhost:8080/{route}``

where `{route}` represents the specific path of an API endpoint. For example:

``http://localhost:8080/api/v0.0.1/features``

## Endpoints

This section describes the behavior of each endpoint in the mockup. In general, the following parameters are always validated:

* The `{apiversion}` parameter value must follow the format `v0.0.1`.
* The `{iri}` parameter value must be a syntactically valid IRI.
* The `{iirdsPackageFilePath}` parameter value must be a valid Linux file path.

### `/api/{apiversion}/resources?query=true`

Restrictions:

* The mockup returns the same query result in json-ld format independent of the query in the body
* Query parameters `offset`, `maxCount`, and `format`  get ignored

### `/api/{apiversion}/resources/schema`

Restrictions:

* The result contains only a subset of the full schema.

### `/api/{apiversion}/resources/iri`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/topics/{iri}`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/fragments/{iri}`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/documents/{iri}`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/packages/{iri}`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/packages/{iri}/files/{iiRDSPackageFilePath}`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/packages/{iri}/content`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/informationunits/{iri}/directorynodes`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/roots`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/children`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/parents`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/previous`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/next`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/resources/directorynodes/{iri}/trees`

Restrictions:

* The result is always the same, regardless of the provided IRI.

### `/api/{apiversion}/sparql`

* The syntax of the SPARQL query in the request body is checked for correctness. If there are syntax errors, an HTTP 400 status code is returned.
* The `{queryType}` parameter value must be `select`.

Restrictions:

* The result is always the same, regardless of the SPARQL query.
* The result is always returned in JSON format, regardless of the `{queryResultFormat}` parameter value.

### `/api/{apiversion}/features`

Always returns the same JSON content:

```JSON
[
  "query.sparql.select",
  "query.native"
]
```
