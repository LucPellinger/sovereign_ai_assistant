const path = require('path');
const process = require('process');

module.exports = {
  /**
  * Some features of this specification are optional in their implementation. To clarify which features are part of a particular API implementation, the API provides an endpoint that can be used to retrieve a list of IDs representing supported features.

**Mapping between IDs and endpoints:**
| Return Value        |   Endpoint   |
| -----------         | -----------  |
| query.sparql.select | /api/{apiversion}/sparql?select       |
| query.native        | /api/{apiversion}/resources?query     |

  * @param options.apiversion Version of the API 

  */
  retrieveSupportedApiFeatures: async (options) => {
    var data = [
      "query.sparql.select",
      "query.native"
    ]
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * Retrieve iiRDS resources via a query provided in the request body.
  * There are two types of queries: iiRDS queries (`iirdsquery`) 
  * and native queries (`nativequery`). 
  * The type of the query is given in the request body.
  * The iiRDS query is defined by a schema. It allows predicate logic
  * and hierarchical queries. 
  * Native queries are specific to the implementing system.
  * 
  * The result of a query is a JSON-LD represenation of the iiRDS RDF resources.
  * @param options.apiversion Version of the API   
  * @param options.maxCount The maximum number of results to return   
  * @param options.offset Defines the zero-based index of the initial result list from which results are returned.
  * @param options.query  
  */
  retrieveIirdsRdfResourcesViaQuery: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsReq": "http://iirds.org/schema/iirds-request#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "pifan": "https://www.i4icm.de/pifan#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "vcard": "http://www.w3.org/2006/vcard/ns#"
      },
      "@graph": [
        {
          "@type": "iirdsReq:QueryResults",
          "iirdsReq:count": "1",
          "iirdsReq:offset": "0",
          "iirdsReq:results": {
            "@type": "rdf:Seq",
            "rdf:_1": {
              "iirdsReq:resource": {
                "@id": "http://myCompany.com/versions/io_1/de/1"
              },
              "iirdsReq:score": "1.0"
            }
          }
        },
        {
          "@id": "http://myCompany.com/versions/io_1/de/1",
          "@type": "iirds:Topic",
          "iirds:dateOfCreation": {
            "@type": "xsd:dateTimeStamp",
            "@value": "2019-01-09T09:52:00+01:00"
          },
          "iirds:has-content-lifecycle-status": {
            "@id": "_:N89ddb41492b04fa998c2bfe727eceb69"
          },
          "iirds:has-rendition": {
            "@id": "_:N049bb0f348f745dc8098c2e045989a1d"
          },
          "iirds:has-topic-type": {
            "@id": "iirds:GenericTask"
          },
          "iirds:is-applicable-for-document-type": [
            {
              "@id": "iirds:RepairInstructions"
            },
            {
              "@id": "iirds:OperatingInstructions"
            },
            {
              "@id": "iirds:MaintenanceInstructions"
            },
            {
              "@id": "iirds:QuickGuide"
            }
          ],
          "iirds:is-part-of-package": {
            "@id": "http://myCompany.com/iiRDS-parent"
          },
          "iirds:language": "en",
          "iirds:relates-to-component": [
            {
              "@id": "https://www.i4icm.de/pifan#PIFan"
            },
            {
              "@id": "https://www.i4icm.de/pifan#Rotor"
            }
          ],
          "iirds:relates-to-product-lifecycle-phase": [
            {
              "@id": "iirds:Maintenance"
            },
            {
              "@id": "iirdsMch:Cleaning"
            }
          ],
          "iirds:relates-to-product-variant": {
            "@id": "https://www.i4icm.de/pifan#X5-DH2"
          },
          "iirds:relates-to-qualification": [
            {
              "@id": "https://www.i4icm.de/pifan#ServiceTechnician"
            },
            {
              "@id": "https://www.i4icm.de/pifan#Operator"
            }
          ],
          "iirds:rights": "Content Copyright (c) 2015, PI-Fan Project\niiRDS Implementation Copyright (c) 2019, iiRDS Consortium\n\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION aOF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\nTHE SOFTWARE.",
          "iirds:title": "Cleaning the rotor"
        },
        {
          "@id": "_:N89ddb41492b04fa998c2bfe727eceb69",
          "@type": "iirds:ContentLifeCycleStatus",
          "iirds:dateOfStatus": {
            "@type": "xsd:dateTimeStamp",
            "@value": "2019-08-11T09:52:00+01:00"
          },
          "iirds:has-content-lifecycle-status-value": {
            "@id": "iirds:Reviewed"
          },
          "iirds:relates-to-party": {
            "@id": "http://myCompany.com/supplier/SupCo"
          }
        },
        {
          "@id": "_:N049bb0f348f745dc8098c2e045989a1d",
          "@type": "iirds:Rendition",
          "iirds:format": "application/xhtml+xml",
          "iirds:source": "content/6_Maintenance/6_1_rotor_cleaning.xhtml"
        }
      ]
    },
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns properties, object resources and RDF Literals of that directory node in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesAndObjectRessourcesForIirdsDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns properties, object resources 
  * and RDF Literals of all child iirds:DirectoryNode in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesForAllChildrenOfDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns properties, object resources and RDF Literals 
  * of the following sibling iirds:DirectoryNode in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesForFollowingSiblingDirectoryNodeOfDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns properties, object resources and RDF Literals of all parent iirds:DirectoryNode in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesForAllParentsOfDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns properties, object resources and RDF Literals 
  * of the previous sibling iirds:DirectoryNode in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesForPreviousSiblingDirectoryNodeOfDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode)
  * as a parameter and returns in [JSON-LD format](https://w3c.github.io/json-ld-syntax/), 
  * properties, object resources and RDF Literals of all 
  * [root level iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#hierarchical-navigation) 
  * related to that iirds:InformationUnit.
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  getPropertiesOfAllRootLevelDirectoryNodesForGivenDirectoryNode: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * By IRI of a given iiRDS directory node, retrieve the graph of trees the directory 
  * node appears in (JSON-LD format). The graph contains properties and resources (IRIs, literals, blank nodes) 
  * to which these properties link/point/relate.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrieveDirectoryNodeTreesForDirectoryNodes: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "iirds:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents",
            "@type": "iirds:DirectoryNodeType"
          },
          "iirds:has-first-child": {
            "@id": "iirds:N3267e132c2f948bca37ea945695c9a8b",
            "@type": "iirds:DirectoryNode"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1",
            "@type": "iirds:InformationUnit"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        },
        {
          "@id": "iirds:N3267e132c2f948bca37ea945695c9a8b",
          "@type": "iirds:DirectoryNode",
          "iirds:has-first-child": {
            "@id": "iirds:N3267e132c234575",
            "@type": "iirds:DirectoryNode"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/21",
            "@type": "iirds:InformationUnit"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "Maintenance"
          }
        },
        {
          "@id": "iirds:N3267e132c234575",
          "@type": "iirds:DirectoryNode",
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1243",
            "@type": "iirds:InformationUnit"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "Clean the rotor"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:Document](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Document)
  * as a parameter and returns properties, object resources and RDF Literals of that document in 
  * [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesOfIirdsDocument: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "http://metadata.example.com/iirds/fragments/E01/languages/en/versions/1",
          "@type": "iirds:Fragment",
          "iirds:title": "Intended Use",
          "iirds:language": "en",
          "iirds:has-subject": [
            {
              "@id": "iirds:IntendedUse",
              "@type": "iirds:InformationSubject"
            }
          ],
          "iirds:has-topic-type": [
            {
              "@id": "iirds:GenericConcept",
              "@type": "iirds:TopicType"
            }
          ],
          "iirds:is-part-of-package": [
            {
              "@id": "http://myCompany.com/iiRDS-parent",
              "@type": "iirds:Package"
            }
          ],
          "iirds:relates-to-product-variant": [
            {
              "@id": "https://www.i4icm.de/pifan#X5-DH2",
              "@type": "iirds:ProductVariant"
            }
          ],
          "iirds:relates-to-qualification": [
            {
              "@id": "https://www.i4icm.de/pifan#Operator",
              "@type": "iirds:Qualification"
            }
          ],
          "iirds:has-rendition": {
            "@type": "iirds:Rendition",
            "id": "_:475634534667",
            "iirds:format": "application/xhtml+xml",
            "iirds:source": "content/07_Troubleshooting.html"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iirds:Fragment](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Topic)
  * as a parameter and returns properties, object resources and RDF Literals 
  * of that fragment in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesOfIirdsFragment: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "http://metadata.example.com/iirds/fragments/E01/languages/en/versions/1",
          "@type": "iirds:Fragment",
          "iirds:title": "Event code E01",
          "iirds:language": "en",
          "iirds:has-subject": [
            {
              "@id": "iirds:IntendedUse",
              "@type": "iirds:InformationSubject"
            }
          ],
          "iirds:has-topic-type": [
            {
              "@id": "iirds:GenericConcept",
              "@type": "iirds:TopicType"
            }
          ],
          "iirds:is-applicable-for-document-type": [
            {
              "@id": "iirds:OperatingInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:RepairInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:QuickGuide",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:MaintenanceInstructions",
              "@type": "iirds:DocumentType"
            }
          ],
          "iirds:is-part-of-package": [
            {
              "@id": "http://myCompany.com/iiRDS-parent",
              "@type": "iirds:Package"
            }
          ],
          "iirds:relates-to-component": [
            {
              "@id": "https://www.i4icm.de/pifan#PIFan",
              "@type": "iirds:Component"
            }
          ],
          "iirds:relates-to-product-variant": [
            {
              "@id": "https://www.i4icm.de/pifan#X5-DH2",
              "@type": "iirds:ProductVariant"
            }
          ],
          "iirds:relates-to-qualification": [
            {
              "@id": "https://www.i4icm.de/pifan#Operator",
              "@type": "iirds:Qualification"
            }
          ],
          "iirds:has-rendition": [
            {
              "@type": "iirds:Rendition",
              "id": "_:475634534667",
              "iirds:format": "application/xhtml+xml",
              "iirds:source": "content/07_Troubleshooting.html"
            }
          ]
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an [iirds:Package](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Document) as a parameter and returns properties, object resources and RDF Literals of that ``iirds:Package`` in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesOfIirdsPackage: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "http://myCompany.com/iiRDS-parent",
          "@type": "iirds:Package",
          "iirds:iiRDSVersion": "1.1",
          "iirds:has-rendition": {
            "@type": "iirds:Rendition",
            "id": "_:657787543325",
            "iirds:format": "application/iirds+zip",
            "iirds:source": "nested-package.iirds"
          }
        }
      ]
    },
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:Package](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Document)
  * and a file path relative to the root of the corresponding
  * [iiRDS container](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#iirds-container)
  * as parameters and returns the corresponding file.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iiRDSContainerFilePath A file path relative to the root of the [iiRDS container](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#iirds-container) which corresponds to the iiRDS package provided with ``{iri}`` parameter.
  * @param options.iri IRI of an iiRDS resource 
  */
  retrieveSpecificFileFromIirdsPackage: async (options) => {
    var data = path.join(process.cwd(), 'response_assets', '6_1_Rotor_cleaning.xhtml'),
      status = 200;

    console.log(data)

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an
  * [iirds:Topic](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Topic)
  * as a parameter and returns properties, object resources and RDF Literals of that topic in
  * [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesOfIirdsTopic: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "http://myCompany.com/versions/io_1/de/1",
          "@type": "iirds:Topic",
          "iirds:title": "Intended use",
          "iirds:language": "en",
          "iirds:has-subject": [
            {
              "@id": "iirds:IntendedUse",
              "@type": "iirds:InformationSubject"
            }
          ],
          "iirds:has-topic-type": [
            {
              "@id": "iirds:GenericConcept",
              "@type": "iirds:TopicType"
            }
          ],
          "iirds:is-applicable-for-document-type": [
            {
              "@id": "iirds:OperatingInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:RepairInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:QuickGuide",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:MaintenanceInstructions",
              "@type": "iirds:DocumentType"
            }
          ],
          "iirds:is-part-of-package": [
            {
              "@id": "http://myCompany.com/iiRDS-parent",
              "@type": "iirds:Package"
            }
          ],
          "iirds:relates-to-component": [
            {
              "@id": "https://www.i4icm.de/pifan#PIFan",
              "@type": "iirds:Component"
            }
          ],
          "iirds:relates-to-product-variant": [
            {
              "@id": "https://www.i4icm.de/pifan#X5-DH2",
              "@type": "iirds:ProductVariant"
            }
          ],
          "iirds:relates-to-qualification": [
            {
              "@id": "https://www.i4icm.de/pifan#Operator",
              "@type": "iirds:Qualification"
            }
          ],
          "iirds:has-rendition": [
            {
              "@type": "iirds:Rendition",
              "id": "_:736543474854342",
              "iirds:format": "application/xhtml+xml",
              "iirds:source": "content/2_ProductDescription/2_1_IntendedUse.xhtml"
            }
          ]
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iirds:InformationUnit](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_InformationUnit)
  * as a parameter and returns in [JSON-LD format](https://w3c.github.io/json-ld-syntax/), properties, object resources and RDF Literals of all [iirds:DirectoryNode](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_DirectoryNode) related to that iirds:InformationUnit.
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  * 
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrievePropertiesOfDirectoryNodeBelongingToInformationUnit: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "_:N11ccfca5fe9541b0b294fc8ff0ae2c11",
          "@type": "iirds:DirectoryNode",
          "iirds:has-directory-structure-type": {
            "@id": "iirds:TableOfContents"
          },
          "iirds:has-first-child": {
            "@id": "_:N3267e132c2f948bca37ea945695c9a8b"
          },
          "iirds:relates-to-information-unit": {
            "@id": "http://myCompany.com/versions/io_1/de/1"
          },
          "rdfs:label": {
            "@language": "en",
            "@value": "PI-FAN Operating Manual"
          }
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an [iirds:InformationUnit](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#rdfclasses_core_Package) and a ``mimetype`` (target format) as parameters and returns the content of that ``iirds:InformationUnit`` in the specified format.
Whether embedded content content will be part of the response can be controlled with the optional boolean ``embeddings`` query parameter.

  * @param options.apiversion Version of the API   * @param options.iri IRI of an iiRDS resource   * @param options.mimetype mimetype   * @param options.embeddings embeddings 

  */
  retrieveRenditionOfInformationUnitInSpecificFormat: async (options) => {
    var data = path.join(process.cwd(), 'response_assets', '6_1_Rotor_cleaning.xhtml'),
      status = 200;

    return {
      status: status,
      data: data,
      options: {
        headers:{
          "content-type": "text/html"
        }
      }
    };
  },

  /**
  * This endpoint takes the IRI of an ``iirds:Package`` as parameter and returns
  * the content of the corresponding
  * [iiRDS container](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#iirds-container)
  * as ZIP archive (application/iirds+zip).
  * 
  * @param options.apiversion Version of the API   
  *  @param options.iri IRI of an iiRDS resource 
  */
  retrieveIirdsContainerAsZip: async (options) => {
    var data = path.join(process.cwd(), 'response_assets', 'PI-Fan.iirds'),
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint returns the iiRDS RDF schema as implemented on the target systems of this API.
  * The response of this endpoint contains at least the 
  * [iiRDS Core RDF Schema](https://iirds.org/fileadmin/downloads/documents/rdfs/iirds-core.rdf)
  * along with any other [iiRDS extensions](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#iirds-domains-and-proprietary-extensions)
  * used within the system.
  *
  * @param options.apiversion Version of the API 
  */
  retrieveIirdsSchema: async (options) => {

    var data = {
      "@context": {
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "dcterms": "http://purl.org/dc/terms/",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
        "schema": "http://schema.org/",
        "dc11": "http://purl.org/dc/elements/1.1/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "iirds": "http://iirds.tekom.de/iirds#"
      },
      "@graph": [
        {
          "@id": "http://iirds.tekom.de/iirds#Document",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": "A document consists of one or more files. It can consist of topics. The resource is either a blank node (when there is no file representing the document) or a file in the iiRDS package."
            },
            {
              "@language": "en",
              "@value": "IRI: required"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "information unit that consists of an ordered set of information intended by the sender to be regarded as an entity"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Dokument"
            },
            {
              "@language": "en",
              "@value": "document"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#InformationUnit"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#DocumentType",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": "Document types define the intended purpose of a document."
            },
            {
              "@language": "en",
              "@value": "IRI: required"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "type of information arranged in a document defined with respect to its specified purpose, function, and form of presentation"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Dokumentart"
            },
            {
              "@language": "en",
              "@value": "document type"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#InformationType"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#DocumentationMetadata",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": {
            "@language": "en",
            "@value": "Not intended to be used directly. Use the subclasses instead."
          },
          "rdfs:comment": {
            "@language": "en",
            "@value": "information that describes the context to which iiRDS resources apply"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Metadaten der Dokumentation"
            },
            {
              "@language": "en",
              "@value": "documentation metadata"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#iirdsDomainEntity"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#DownTime",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": ""
            },
            {
              "@language": "en",
              "@value": "IRI: optional"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "period of time during which an item is not in condition to perform its intended function"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Stillstandzeit"
            },
            {
              "@language": "en",
              "@value": "down time"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#PlanningTime"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#Topic",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": "The resource of a topic is a file in the iiRDS package."
            },
            {
              "@language": "en",
              "@value": "IRI: required"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "information unit that covers a single subject"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Topic"
            },
            {
              "@language": "en",
              "@value": "topic"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#InformationUnit"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#TopicType",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": "Possible types include task, learning, and concept. Information units that represent topics may have one or more has-topic-type properties that define the topic's information type. Topics without a has-topic-type property are generic topics, with no specific type."
            },
            {
              "@language": "en",
              "@value": "IRI: required"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "type of information determined according to functional principles"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Topictyp"
            },
            {
              "@language": "en",
              "@value": "topic type"
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#InformationType"
          }
        },
        {
          "@id": "http://iirds.tekom.de/iirds#Troubleshooting",
          "@type": "rdfs:Class",
          "http://iirds.tekom.de/iirds#description": [
            {
              "@language": "en",
              "@value": "Typical troubleshooting topics contain sections with a description of the system's behavior or symptom, the cause for the error, and a remedy for the error."
            },
            {
              "@language": "en",
              "@value": "IRI: required"
            }
          ],
          "rdfs:comment": {
            "@language": "en",
            "@value": "topic type that provides an explanation for symptoms, diagnosis, and resolution of problems"
          },
          "rdfs:label": [
            {
              "@language": "de",
              "@value": "Störungsbeseitigung"
            },
            {
              "@language": "en",
              "@value": "troubleshooting "
            }
          ],
          "rdfs:subClassOf": {
            "@id": "http://iirds.tekom.de/iirds#TopicType"
          }
        }
      ]
    },
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes the IRI of an 
  * [iiRDS RDF resource](https://www.iirds.org/fileadmin/iiRDS_specification/20231110-1.2-release/index.html#/class-definitions)
  * as a parameter and returns properties, object resources and RDF Literals 
  * of that resource in [JSON-LD format](https://w3c.github.io/json-ld-syntax/).
  * Notice: iiRDS allows various resources to be available in the form of blank nodes.
  * A blank node can not be queried by IRI due to not being identified by such.
  * For that, properties and object resources of blank nodes must always be fully resolved.
  * This requires for recursive querying whenever a blank node is available as an object resource.
  *
  * @param options.apiversion Version of the API   
  * @param options.iri IRI of an iiRDS resource 
  */
  retrieveIirdsResourceByIri: async (options) => {
    var data = {
      "@context": {
        "iirds": "http://iirds.tekom.de/iirds#",
        "iirdsMch": "http://iirds.tekom.de/iirds/domain/machinery#",
        "iirdsSft": "http://iirds.tekom.de/iirds/domain/software#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "vcard": "http://www.w3.org/2006/vcard/ns#",
        "xsd": "http://www.w3.org/2001/XMLSchema#"
      },
      "@graph": [
        {
          "@id": "urn:uuid:08102300-4bfd-46b3-a72e-a6274dcd0461",
          "@type": "iirds:Topic",
          "iirds:title": "Technical data",
          "iirds:language": "en",
          "iirds:has-subject": [
            {
              "@id": "iirds:GenericTechnicalData",
              "@type": "iirds:InformationSubject"
            }
          ],
          "iirds:has-topic-type": [
            {
              "@id": "iirds:GenericReference",
              "@type": "iirds:TopicType"
            }
          ],
          "iirds:is-applicable-for-document-type": [
            {
              "@id": "iirds:QuickGuide",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:RepairInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:MaintenanceInstructions",
              "@type": "iirds:DocumentType"
            },
            {
              "@id": "iirds:OperatingInstructions",
              "@type": "iirds:DocumentType"
            }
          ],
          "iirds:is-part-of-package": [
            {
              "@id": "urn:uuid:0ec79b45-73ed-4afe-99ac-658cc3a2c2df",
              "@type": "iirds:Package"
            }
          ],
          "iirds:relates-to-component": [
            {
              "@id": "https://www.i4icm.de/pifan#PIFan",
              "@type": "iirds:Component"
            }
          ],
          "iirds:relates-to-product-variant": [
            {
              "@id": "https://www.i4icm.de/pifan#X5-DH2",
              "@type": "iirds:ProductVariant"
            }
          ],
          "iirds:relates-to-qualification": [
            {
              "@id": "https://www.i4icm.de/pifan#Operator",
              "@type": "iirds:Qualification"
            },
            {
              "@id": "https://www.i4icm.de/pifan#ServiceTechnician",
              "@type": "iirds:Qualification"
            },
          ],
          "iirds:has-rendition": [
            {
              "@type": "iirds:Rendition",
              "@id": "_:node40",
              "iirds:format": "application/xhtml+xml",
              "iirds:source": "content\\2_ProductDescription\\2_3_TechData_X5-DH2.xhtml"
            }
          ]
        }
      ]
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },

  /**
  * This endpoint takes a [SPARQL](https://w3c.github.io/sparql-query/spec/) 
  * query string provided with the requestBody of the POST request and runs 
  * the query on the SPARQL query engine of the system the API is implemented on.
  * NOTICE: The implementation of this endpoint is optional. This endpoint 
  * can only be implemented when the system on which this API is implemented 
  * on supports SPARQL.
  * 
  * @param options.apiversion Version of the API
  * @param options.queryResultFormat The result format in which the results 
  * are to be returned.
  * NOTICE: This parameter is only allowed in in conjunction with ``select``
  * parameter
  * 
  * @param options.queryType Used to indicate the query type of the SPARQL query.
  */
  retrieveSparqlQueryResults: async (options) => {
    var data = {
      "head": {
        "vars": [
          "topic"
        ]
      },
      "results": {
        "bindings": [
          {
            "topic": {
              "type": "uri",
              "value": "urn:uuid:cf0a5c68-c2b1-45dd-a3cb-cbd2861f6e61"
            }
          },
          {
            "topic": {
              "type": "uri",
              "value": "urn:uuid:64792352-b96f-452a-90d8-5283515c7fc2"
            }
          }
        ]
      }
    }
      ,
      status = 200;

    return {
      status: status,
      data: data
    };
  },
};
